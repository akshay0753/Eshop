
from django.urls import path
from store.views.home import Index
from store.views.signup import Signup
from store.views.login import Login, logout
from store.views.cart import Cart
from store.views.checkout import CheckOut
from store.views.orders import OrderView






urlpatterns = [
    path('',Index.as_view(), name="index_page"),
    path('signup/',Signup.as_view() ),
    path("login/",Login.as_view(), name="login"),
    path("logout/",logout, name="logout"),
    path("cart/",Cart.as_view(), name="cart"),
    path("checkout",CheckOut.as_view(), name="checkout"),
    path("order",OrderView.as_view(), name="order"),
    
    
]

