from django.shortcuts import redirect


def use_middleware(get_response):
    def middleware_add(request):
        if not request.session.get("customer"):
            return redirect("login")
        res = get_response(request)
        return res
    return middleware_add