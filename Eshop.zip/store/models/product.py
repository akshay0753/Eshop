from django.db import models
from .category import Category

class Product(models.Model):
    name = models.CharField(max_length=150)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    description = models.CharField(max_length=150, default=" ", null=True)
    image = models.ImageField(upload_to='upload/products/')
    
    @staticmethod
    def product_get():
        return Product.objects.all() 
    @staticmethod
    def get_all_product_by_id(category_id):
        if category_id:  
            return Product.objects.filter(category=category_id)
        else:
            return Product.product_get()

 
