from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View

class Login(View):
    def get(self, request):
        return render(request, "login.html")
    
    def post(self, request):
        email = request.POST.get("email")
        password = request.POST.get("password")
        customer = Customer.check_valid_customer_by_email(email)
        # print(Customer.objects.get(email = email).password)
        error_message = None
        if customer:
            check =  check_password(password, customer.password)
            if check == True:
                request.session['customer'] = customer.id
                print(request.session.get('customer'))
                return redirect("index_page")
            else:
                error_message ="password is invalid...!!"
        else:
            error_message ="Email  is invalid...!!"
        return render (request, "login.html", {"error": error_message})
         
        


def logout(request):
    request.session.clear()
    return redirect("index_page")