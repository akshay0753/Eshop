from django.shortcuts import render, redirect
from store.models.product import Product
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View

class Signup(View):
    def get(self,request):
        return render(request, "signup.html")
    
    def post(self, request):
        firstname = request.POST.get("firstname")
        lastname = request.POST.get("lastname")
        phone = request.POST.get("phone")
        email= request.POST.get("email")
        password = request.POST.get("password")
        sh_password = make_password(password)
        error_message = None
        if not firstname:
            error_message = "firstname must requried"
        elif not lastname:
            error_message = "lastname must be required"
        elif not email:
            error_message = "email must be required"
        elif not phone:
            error_message = "phone must be required"
        if error_message:
            return render(request, "signup.html", {"error" : error_message})
        elif not error_message:
            customer = Customer(firstname=firstname, lastname=lastname, phone=phone, email=email, password=sh_password)
            customer.save()
            return redirect("login")
        



    
