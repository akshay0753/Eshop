from django.shortcuts import render, redirect
from store.models.product import Product
from django.contrib.auth.hashers import check_password
from django.views import View

class Cart(View):
    def get(self, request):
        cart = request.session.get("cart")
        ids = list(cart.keys())
        product = Product.objects.filter(id__in=ids)
        return render(request, "cart.html",{"products":product})
    
    # def post(self, request):
    #     email = request.POST.get("email")
    #     password = request.POST.get("password")
    #     customer = Customer.check_valid_customer_by_email(email)
    #     # print(Customer.objects.get(email = email).password)
    #     error_message = None
    #     if customer:
    #         check =  check_password(password, customer.password)
    #         if check == True:
    #             request.session['customer'] = customer.id
    #             print(request.session.get('customer'))
    #             return redirect("index_page")
    #         else:
    #             error_message ="password is invalid...!!"
    #     else:
    #         error_message ="Email  is invalid...!!"
    #     return render (request, "login.html", {"error": error_message})
         
        
